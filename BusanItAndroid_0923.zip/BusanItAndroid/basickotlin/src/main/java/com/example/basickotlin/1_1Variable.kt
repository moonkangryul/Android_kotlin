package com.example.basickotlin

// 메인함수 실행: ctrl + shift + f10 혹은 런버튼 아이콘 클릭해서 실행
// 주석 : ctrl + /
// 한줄삭제 : ctrl + y
// 한줄이동 : ctrl + shift + 화살표 위,아래


// 1. 변수
// 변수 선언 형식
// val(혹은 var) 변수명:타입 = 값

// var - 변수    val - 상수
var a:Int = 10
val b:Int = 20

// 초기화 미루기 : 변수선언 후 초기화시 null로 선언할 필요가 없을 때 사용
// 1. late init : 최상단, 클래스 내부에서 초기화를 미룰 수 있다. (단, 기본 타입은 X)
lateinit var late:String
class varialble{
    //클래스 내부에서 초기화 미루기
    lateinit var late2:String
}

// 2. by lazy : 선언과 동시에 초기화를 해줌
// 호출시점에서 최초 1회 초기화가 된다. -> 호출시점에 초기화가 되기때문에 초기화 미루기
val late2:Int by lazy{
    println("초기화 미루기2")
    10
}

// 메인 함수
fun main(){
    late = "초기화 미루기 1번 입니다."
    a = 11
   // b = 12 -> 문법적 오류 발생
   // print("Hello World")
   // println(late)
    println(late2)
    println(late2)
}


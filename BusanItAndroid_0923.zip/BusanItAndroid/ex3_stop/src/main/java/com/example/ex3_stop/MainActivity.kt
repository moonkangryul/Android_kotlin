package com.example.ex3_stop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.widget.Toast
import com.example.ex3_stop.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    //스탑워치를 멈춘 시간
    var initTime = 0L
    //뒤로가기 버튼의 시간 계산용
    var pauseTime = 0L
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.startBtn.setOnClickListener{
            binding.chronometer.base=
                SystemClock.elapsedRealtime()+pauseTime
            binding.chronometer.start()
            binding.stopBtn.isEnabled=true
            binding.resetBtn.isEnabled=true
            binding.startBtn.isEnabled=false
        }
        binding.stopBtn.setOnClickListener{
            pauseTime = binding.chronometer.base -
                SystemClock.elapsedRealtime()
            binding.chronometer.stop()
            binding.stopBtn.isEnabled=false
            binding.resetBtn.isEnabled=true
            binding.startBtn.isEnabled=true
        }
        binding.resetBtn.setOnClickListener{
            pauseTime = 0L
            binding.chronometer.base=
                SystemClock.elapsedRealtime()
            binding.chronometer.stop()
            binding.stopBtn.isEnabled=false
            binding.resetBtn.isEnabled=false
            binding.startBtn.isEnabled=true
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if(keyCode===KeyEvent.KEYCODE_BACK){
            if(System.currentTimeMillis() - initTime > 3000){
                Toast.makeText(this,"종료하려면 한 번 더 누르세요",Toast.LENGTH_SHORT).show()
                initTime = System.currentTimeMillis()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

}


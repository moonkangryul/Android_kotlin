package com.example.ex6_jetpack_recycler

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.ex6_jetpack_recycler.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var adapter: MyAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //임의의 데이터 생성
        val datas = mutableListOf<String>()
        for(i in 1..10){
        //원본 소스
        datas.add("아이템 ${i}")

            //StaggeredGridLayoutManager 테스트를 위한 데이터 준비
//            if(i == 3 || i == 4 ||i == 6 ||i == 8 ){
//                datas.add("동해물과 백두산이 마르고 닳도록")
//            }else{
//                datas.add("아이템 ${i}")
//            }
        }
        adapter = MyAdapter(datas)
//        //LinearLayoutManager 사용
//        val layoutManager = LinearLayoutManager(this)
//        layoutManager.orientation = LinearLayoutManager.VERTICAL
//        binding.recyclerView.layoutManager = layoutManager

        //GridLayoutManager 사용
//        val layoutManager = GridLayoutManager(
//            this,
//            3,
//            GridLayoutManager.HORIZONTAL,
//            true
//        )

        //StaggeredGridLayoutManager 사용
//        val layoutManager = StaggeredGridLayoutManager(
//            2, StaggeredGridLayoutManager.VERTICAL
//        )

        //리사이클러 뷰 적용
//        binding.recyclerView.layoutManager = layoutManager
//        binding.recyclerView.adapter = adapter
//        binding.recyclerView.addItemDecoration(
//            //DividerItemDecoration(this,LinearLayoutManager.VERTICAL)
//            MyAdapter.MyDecoration(this)
//        )

        //viewPager2 적용: 리사이클러뷰 어댑터를 이용
        //binding.viewPager.adapter = adapter

        //viewPager2 적용: 프래그먼트 어댑터를 이용
        binding.viewPager.adapter = MyFragmentPagerAdapter(this)

        //새로운 아이템 추가
//        binding.addItem.setOnClickListener {
//            adapter.addItem()
//        }
//        //아이템 삭제
//        binding.removeItem.setOnClickListener {
//            adapter.removeItem()
//        }
    }
}
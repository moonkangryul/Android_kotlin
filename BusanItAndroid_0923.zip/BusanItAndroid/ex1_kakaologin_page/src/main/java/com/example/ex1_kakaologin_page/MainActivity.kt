package com.example.ex1_kakaologin_page

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.ex1_kakaologin_page.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        var boolean = true
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.visibleBtn.setOnClickListener{
            if (boolean) {
                binding.targetView.visibility = View.INVISIBLE
                boolean = false
            }else {
                binding.targetView.visibility = View.VISIBLE
                boolean = true
            }
        }
    }
}
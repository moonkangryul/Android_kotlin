package com.example.mytodo

import android.app.Activity
import android.app.DatePickerDialog
import android.app.appsearch.StorageInfo
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.DatePicker
import androidx.appcompat.app.AppCompatActivity
import com.example.mytodo.databinding.ActivityAddBinding

class AddActivity : AppCompatActivity() {
    lateinit var binding : ActivityAddBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)


            val datePicker = DatePickerDialog(this, object : DatePickerDialog.OnDateSetListener {
                override fun onDateSet(view: DatePicker?, year: Int, month: Int, day: Int) {
                    binding.date.setText("${year}년 ${month}월 ${day}일")
                }
            }, 2022, 9, 30)

            binding.datePick.setOnClickListener {
                datePicker.show()
            }
        }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.menu_add_save -> {
                val inputData = binding.addEditView.text.toString()
                val date = binding.date.text.toString()

                val intent = intent
                var todoText = binding.addEditView.text.toString()
                if(todoText.isBlank()){
                    setResult(Activity.RESULT_CANCELED,intent)
                }else{
                    val db = DBHelper(this).writableDatabase
                    db.execSQL(
                        "insert into TODO_DB(todo,date) values(?,?)",
                        arrayOf<String>(inputData,date)
                    )
                    db.close()
                    Log.d("myLog", "${date}")
                    intent.putExtra("result",inputData)
                    intent.putExtra("date",date)
                    setResult(Activity.RESULT_OK,intent)

                }
                finish()
                true
            }
            else->true
        }
        return super.onOptionsItemSelected(item)
    }
}
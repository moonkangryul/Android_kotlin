package com.example.mytodo

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.DatePicker
import android.widget.Toast
import com.example.mytodo.databinding.ActivityUpdateBinding


class UpdateActivity : AppCompatActivity() {
    lateinit var binding : ActivityUpdateBinding
    lateinit var todo:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityUpdateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intent = intent
        todo = intent.getStringExtra("todo").toString()
        binding.updateEditView.setText(todo)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val datePicker = DatePickerDialog(this, object : DatePickerDialog.OnDateSetListener {
                override fun onDateSet(view: DatePicker?, year: Int, month: Int, day: Int) {
                   val date = binding.date.setText("${year}년 ${month + 1}월 ${day}일")
                    Log.d("myLog", "${year}년 ${month + 1}월 ${day}일")

                }

            }, 2022, 9, 30)

            binding.datePick.setOnClickListener {
                datePicker.show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.menu_add_save -> {
                val updateData = binding.updateEditView.text.toString()
                val updatedate = binding.date.text.toString()
                if(updateData.isBlank()){
                    //할일이 비어 있을 때
                    Toast.makeText(this,"할일이 비어있습니다.",Toast.LENGTH_SHORT)
                    return false
                }else{
                    //할일이 있을 때
                    val db = DBHelper(this).writableDatabase
                    db.execSQL(
                        "update TODO_DB set todo = ? where todo = ?",
                        arrayOf<String>(updateData,todo)
                    )
                    db.close()
                    val intent = Intent(this,MainActivity::class.java)
                    startActivity(intent)
                }
                finish()
                true
            }
            else->true
        }
        return super.onOptionsItemSelected(item)
    }
}
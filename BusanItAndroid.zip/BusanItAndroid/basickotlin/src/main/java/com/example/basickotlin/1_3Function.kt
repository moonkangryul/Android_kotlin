package com.example.basickotlin

// 함수
// fun이라는 키워드를 이용하여 생성
// 반환타입이 있다면 :타입 추가, 반환타입이 없다면 생략 가능
// 매개변수는 자동으로 val 키워드로 적용

// 함수 선언형식
// fun 함수명(매개변수:타입):반환타입{ 수행문 }

//반환타입과 매개변수가 있는 함수의 형태
fun add(a:Int, b:Int):Int{
    return a+b
}

//함수의 매개변수에 기본값 선언
fun add2(a:Int, b:Int=20):Int{
    return a+b
}


//반환타이과 매개변수가 없는 함수의 대표적인 형태 - main 함수
fun main(){
    //수행문
    add(1,2)
    add2(10) // add2 함수의 a에는 10이 할당되고, b에는 기본값이 적용된다.
    add2(10,30) // add2 함수의 a에는 10이 할당되고, b에는 30이 할당된다.

    //매개변수를 지정해서 호출
    add(b=3,a=1)

    println("결과 확인 : "+add(3,4))
}

package com.example.ex3_event

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import com.example.ex3_event.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity(), View.OnClickListener {
    //터치 이벤트
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        //Log.d("myLog","터치 이벤트 발생")
        //터치 이벤트 좌표값 얻기 : MotionEvent 객체로 획득
        // x : 이벤트가 발생한 뷰의 x 좌표
        // y : 이벤트가 발생한 뷰의 y 좌표
        //Log.d("myLog","x의 좌표값 :${event?.x}, y의 좌표값 : ${event?.y}")

        //터치 이벤트의 종류
        when(event?.action){
            MotionEvent.ACTION_DOWN -> { //클릭을 한상태
                Log.d("myLog","ACTION_DOWN")
            }
            MotionEvent.ACTION_UP ->{ //마우스를 손가락을 뗀 순간
                Log.d("myLog","ACTION_UP")
            }
            MotionEvent.ACTION_MOVE ->{ //화면을 드래그 할 때
                Log.d("myLog","ACTION_MOVE")
            }
        }
        return super.onTouchEvent(event)
    }

    //키 이벤트(소프트 키보드가 아님)
    // 뒤로가기 버튼, 볼륨 업다운 버튼
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        Log.d("myLog","키가 눌렸을 때 발생")
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
       //Log.d("myLog","키를 눌렀다 뗐을 때 발생")
        when(keyCode){
            KeyEvent.KEYCODE_VOLUME_UP ->{
                Log.d("myLog","볼륨업 버튼 클릭시 발생")
            }
            KeyEvent.KEYCODE_VOLUME_DOWN ->{
                Log.d("myLog","볼륨다운 버튼 클릭시 발생")
            }
        }

        return super.onKeyUp(keyCode, event)
    }

    //뒤로가기 버튼 클릭시 함수
    override fun onBackPressed() {
        Log.d("myLog","뒤로가기 버튼 클릭시 발생")
        super.onBackPressed()
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent?): Boolean {
        Log.d("myLog","키를 누르는 동안 발생")
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var boolean = true
        //1. 액티비티에서 인터페이스 구현
        binding.button1.setOnClickListener(this)
        //2. 별도의 핸들러 구현
        binding.button2.setOnClickListener(Handler())

        //롱 클릭 이벤트
        binding.button3.setOnLongClickListener {
            Log.d("myLog", "길게 동안 발생")
            true
        }
        //좋아요 버튼 만들어보기 - 이벤트 처리


//        binding.imageView2.setOnClickListener {
//            if (boolean) {
//                binding.imageView.visibility = View.GONE
//                boolean = false
//            } else {
//                binding.imageView.visibility = View.VISIBLE
//                boolean = true
//            }
//
//        }
        binding.imageView2.setOnClickListener {
            binding.imageView2.visibility = View.GONE
            binding.imageView.visibility = View.VISIBLE
        }
        binding.imageView.setOnClickListener {
            binding.imageView.visibility = View.GONE
            binding.imageView2.visibility = View.VISIBLE
        }


    }



    //1. 액티비티에서 인터페이스 구현
    override fun onClick(p0: View?) {
        Log.d("myLog", "버튼클릭 1.")
    }
}

//2. 별도의 핸들러 구현
class Handler:View.OnClickListener{
    override fun onClick(p0: View?) {
        Log.d("myLog", "버튼클릭 2.")
    }
}
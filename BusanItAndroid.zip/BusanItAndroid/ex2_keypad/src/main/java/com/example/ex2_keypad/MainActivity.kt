package com.example.ex2_keypad

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.ex2_keypad.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*var button : Button = findViewById(R.id.btn1)
        var text : EditText = findViewById(R.id.edit)*/

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        button.setOnClickListener {
//            text.setText("1")
//        }
    }
}